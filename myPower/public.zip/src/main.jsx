import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import 'antd/dist/reset.css';
import Dashboard from './Pages/Dashboard.jsx';
import App from './App.jsx';
import Login from './Login.jsx';

import { AuthProvider } from "./Authcontxt";

createRoot(document.getElementById('root')).render(
  <StrictMode>
<AuthProvider>
     <App/>
</AuthProvider>
  </StrictMode>,
)
