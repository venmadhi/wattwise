import React, { useState, useContext } from "react";
import "./Login.css";
import { FaEnvelope, FaEye, FaEyeSlash, FaPhone } from "react-icons/fa";
import { useNavigate } from "react-router-dom";
import { AuthContext } from "./Authcontxt";

const Login = () => {
  const { login } = useContext(AuthContext);
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [mobile, setMobile] = useState("");
  const [isMobileLogin, setIsMobileLogin] = useState(false);
  const [emailError, setEmailError] = useState("");
  const [mobileError, setMobileError] = useState("");
  const [password, setPassword] = useState("");
  const [passwordError, setPasswordError] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [loginError, setLoginError] = useState("");

  const isValidEmail = (email) => {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
  };

  const isValidMobile = (mobile) => {
    const regex = /^\d{10}$/;
    return regex.test(mobile);
  };

  const isValidPassword = (password) => {
    return password.length >= 8;
  };

  const handleSubmit = async (e) => {
  e.preventDefault();
  setEmailError("");
  setMobileError("");
  setPasswordError("");
  setLoginError("");

  let hasError = false;

  if (isMobileLogin) {
    if (!mobile.trim()) {
      setMobileError("Mobile number is required");
      hasError = true;
    } else if (!isValidMobile(mobile)) {
      setMobileError("Please enter a valid 10-digit mobile number");
      hasError = true;
    }
  } else {
    if (!email.trim()) {
      setEmailError("Email is required");
      hasError = true;
    } else if (!isValidEmail(email)) {
      setEmailError("Please enter a valid email address");
      hasError = true;
    }
  }

  if (!password.trim()) {
    setPasswordError("Password is required");
    hasError = true;
  } else if (!isValidPassword(password)) {
    setPasswordError("Password must be at least 8 characters long");
    hasError = true;
  }

  if (hasError) return;

  setIsLoading(true);

  try {
    const username = isMobileLogin ? mobile : email;
    const loginResponse = await fetch("http://localhost:3001/api/auth/login", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ username, password }),
    });

    const loginData = await loginResponse.json();
    if (!loginResponse.ok) {
      throw new Error(loginData.error || "Failed to log in");
    }

    const { token } = loginData;

    // Fetch user details (including role) using the /me endpoint
    const userResponse = await fetch("http://localhost:3001/api/auth/me", {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    const userData = await userResponse.json();
    if (!userResponse.ok) {
      throw new Error(userData.error || "Failed to fetch user details");
    }

    const role = userData.payload.role || "USER"; // Default to USER if role is not provided
    login(role, token); // Store token and role via AuthContext

    if (role.toLowerCase() === "admin") {
      navigate("/admin-dashboard");
    } else {
      navigate("/dashboard");
    }
  } catch (error) {
    setLoginError(error.message || "Failed to connect to the server. Please try again.");
  } finally {
    setIsLoading(false);
  }
};
  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  const toggleLoginMode = () => {
    setIsMobileLogin(!isMobileLogin);
    setEmailError("");
    setMobileError("");
    setEmail("");
    setMobile("");
  };

  return (
    <div className="login-container">
      <div className="login-right">
        <form className="login-form" onSubmit={handleSubmit}>
          <h2>LOGIN TO YOUR ACCOUNT</h2>
          {loginError && (
            <div
              className="login-error-message"
              style={{ marginBottom: "1rem", textAlign: "center" }}
            >
              {loginError}
            </div>
          )}

          <div
            className={`form-group ${isMobileLogin ? "mobile" : "email"} ${
              isMobileLogin ? mobileError : emailError ? "error" : ""
            }`}
          >
            <div className="input-wrapper">
              {isMobileLogin ? (
                <>
                  <input
                    id="mobile"
                    type="tel"
                    value={mobile}
                    onChange={(e) => setMobile(e.target.value)}
                    className={mobile ? "filled" : ""}
                    placeholder="Mobile Number"
                    maxLength={10}
                  />
                  <label htmlFor="mobile">Mobile Number</label>
                  <FaEnvelope
                    className="input-icon toggle-icon"
                    onClick={toggleLoginMode}
                    title="Use Email instead"
                  />
                </>
              ) : (
                <>
                  <input
                    id="email"
                    type="text"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className={email ? "filled" : ""}
                    placeholder="Email"
                  />
                  <label htmlFor="email">Email</label>
                  <FaPhone
                    className="input-icon toggle-icon"
                    onClick={toggleLoginMode}
                    title="Use Mobile Number instead"
                  />
                </>
              )}
            </div>
            {isMobileLogin && mobileError && (
              <div className="login-error-message">{mobileError}</div>
            )}
            {!isMobileLogin && emailError && (
              <div className="login-error-message">{emailError}</div>
            )}
          </div>

          <div className={`form-group ${passwordError ? "error" : ""}`}>
            <div className="input-wrapper">
              <input
                id="password"
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className={password ? "filled" : ""}
                placeholder="Password"
              />
              <label htmlFor="password">Password</label>
              <div
                className="password-toggle"
                onClick={togglePasswordVisibility}
              >
                {showPassword ? (
                  <FaEyeSlash className="input-icon-eye" />
                ) : (
                  <FaEye className="input-icon-eye" />
                )}
              </div>
            </div>
            {passwordError && (
              <div className="login-error-message">{passwordError}</div>
            )}
          </div>

          <button type="submit" className="login-button" disabled={isLoading}>
            {isLoading ? "LOGGING IN..." : "LOGIN"}
          </button>

          <div className="forgot-password">
            <a href="/forgetpassword">Forgot Password?</a>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Login;